# Approvals in this campaign directory — 2026-10-20 03:40:41 +0700

| bundle | status | approver(s) | contracts | lint | sha256 | owner's file |
|---|---|---|---|---|---|---|
| w1-a-arms | provisional | human:orchestrator-provisional | 13 | READY | `4f1aa460f54ac22d` | - |
| w1-a-evaluator | provisional | human:orchestrator-provisional | 12 | READY | `5c26583976dd936e` | - |
| w2-arms | provisional | human:orchestrator-provisional | 7 | READY | `948a30a2cb3302c1` | - |
| w2-evaluator | provisional | human:orchestrator-provisional | 12 | READY | `e29b89cb10d66dfd` | - |

`provisional` = a TECHNICAL approval by `human:orchestrator-provisional` so that the kernel can compile the contracts and the
evaluation can run (aisef2/product/approval.py accepts `human:<name>` only). It is NOT the owner's acceptance of any
contract; nothing in this directory records owner acceptance. `owner` = the file APPROVE.sh wrote in the workload's
lane directory was adopted as it is (its contracts and requirements checked identical to the sealed bundle).

How the owner's approval replaces a provisional one:

1. The owner runs the lane's APPROVE.sh (`closure-evidence/v2/v2.1/e2/w1-a/APPROVE.sh human:<name>`,
   `.../e2/w2/APPROVE.sh human:<name>`): one `aisef bundle approve` per contract, written beside each bundle.
2. `python3 -P -B e2_setup.py /private/tmp/claude-501/-Users-nghinh-Downloads-projects-ai-sdlc/845c9f11-719f-4f92-a0ed-4f4a07d6e27b/scratchpad/m21/c9/e2-campaign --adopt-owner` — BEFORE the first run_e2.sh or AFTER the last run, never
   in between (refused while the campaign is partial: the first launch seals all manifests, binding the provisional
   files' sha256, and later arms must run on exactly the files their manifests name) — checks each owner file holds
   the same contracts and requirements, keeps the provisional copies under `approved/provisional/`, replaces
   `approved/*.json`, and appends to this file.
3. `python3 -P -B validation/experiments/campaign.py replay --out /private/tmp/claude-501/-Users-nghinh-Downloads-projects-ai-sdlc/845c9f11-719f-4f92-a0ed-4f4a07d6e27b/scratchpad/m21/c9/e2-campaign/out` evaluates every recorded
   candidate again under the owner-approved evaluator (RESULT.json's evaluator_path is the replaced file). Nothing
   printed = every result replays.

What adoption cannot change: runs already made used the provisional copies (their sealed MANIFEST.json binds those
files' sha256 under `bundle` and `evaluator`). For the owner's approval to bind the runs themselves, adopt before
launching — e2_setup.py uses the owner's files on its own when they exist at setup time.
